export interface Days {
    day: string;
    day_temp: string;
    night_temp: string;
  }