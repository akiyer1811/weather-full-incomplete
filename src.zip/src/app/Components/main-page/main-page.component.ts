import { Component, OnInit } from '@angular/core';
import { WeatherService } from '../weather/weather.service';
import { WeatherData } from 'src/app/types/City';
@Component({
  selector: 'app-main-page',
  templateUrl: './main-page.component.html',
  styleUrls: ['./main-page.component.css']
})
export class MainPageComponent implements OnInit {
  isInCart: boolean = false;
  constructor(private weatherService: WeatherService) { }
  cityName: string = 'Paris';
  weatherData?: WeatherData; 
  ngOnInit(): void {
  }

}
