import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-current-temp-card',
  templateUrl: './current-temp-card.component.html',
  styleUrls: ['./current-temp-card.component.css']
})
export class CurrentTempCardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
